package ai;
import java.util.Scanner;
import java.util.Random;
public class AI {
    public static void main(String[] args) {
        Scanner cin= new Scanner(System.in);
        Random rand= new Random();
        test[] ob= new test[6];
        double wheel[]= new double[4];
        double wheelSum=0.0;
        int wheelNumber;
        int z=0;
        int child[]=new int[2];
        ob[4]=new test();
        ob[5]=new test();
        
        double totalPercent;
        
        for(int i=0; i<4; i++){
            ob[i]= new test();
            for(int j=0; j<6; j++){
                ob[i].a[j]=rand.nextInt(2);
            }
        }
        
        while(true){
            totalPercent=0;
            wheelSum=0;
            for(int i=0; i<4; i++){
                ob[i].count=0;
                ob[i].initialPercent=0;
                for(int j=0; j<6; j++){
                    System.out.print(ob[i].a[j]+" ");
                    if(ob[i].a[j]==1){
                        ob[i].count++;
                    }
                }
                ob[i].initialPercent= ob[i].count*100/6;
                System.out.println("\n"+ob[i].initialPercent);
                totalPercent+=ob[i].initialPercent;
            }
            System.out.println("\n");
            for(int i=0; i<4; i++){
                if(ob[i].initialPercent==100){
                    System.out.println(i+1 +" number Parent fulfil all requirement.\nProgram Exiting...");
                    System.exit(0);
                }
            }

            for(int i=0; i<4; i++){
                ob[i].finalPercent= ob[i].initialPercent*100/totalPercent;
                wheelSum+=ob[i].finalPercent;
                wheel[i]=wheelSum;
            }
            for(int k=0; k<4; k++){
                wheelNumber= rand.nextInt(100);
                for(int i=0; i<4; i++){
                    if(wheelNumber<=wheel[i]){
                        ob[i].randCount++;
                        break;
                    }
                }
            }
            for(int i=0; i<2; i++){
                if(ob[0].randCount>=ob[1].randCount){
                    if(ob[0].randCount>=ob[2].randCount){
                        if(ob[0].randCount>=ob[3].randCount){
                            child[i]=0;
                            ob[0].randCount=0;
                        }else{
                            child[i]=3;
                            ob[3].randCount=0;
                        }
                    }else{
                        if(ob[2].randCount>=ob[3].randCount){
                            child[i]=2;
                            ob[2].randCount=0;
                        }else{
                            child[i]=3;
                            ob[3].randCount=0;
                        }
                    }
                }else{
                    if(ob[1].randCount>=ob[2].randCount){
                        if(ob[1].randCount>=ob[3].randCount){
                            child[i]=1;
                            ob[1].randCount=0;
                        }else{
                            child[i]=3;
                            ob[3].randCount=0;
                        }
                    }else{
                        if(ob[2].randCount>=ob[3].randCount){
                            child[i]=2;
                            ob[2].randCount=0;
                        }else{
                            child[i]=3;
                            ob[3].randCount=0;
                        }
                    }
                }
            }


            for(int j=0; j<6; j++){
                if(j<3){
                    ob[4].a[j]=ob[child[0]].a[j];
                    ob[5].a[j]=ob[child[1]].a[j];
                }else{
                    ob[4].a[j]=ob[child[1]].a[j];
                    ob[5].a[j]=ob[child[0]].a[j];
                }
            }

            int k=rand.nextInt(6);

            for(int i=0; i<2; i++){
                if(ob[4+i].a[k]==0){
                    ob[4+i].a[k]=1;
                }else{
                    ob[4+i].a[k]=0;
                }
                for(int j=0; j<6; j++){
                    if(ob[4+i].a[j]==1){
                        ob[4+i].count++;
                    }
                }
                ob[4+i].initialPercent= ob[4+i].count*100/6;
            }
            
            double u=500;
            double v=-1;
            int min=0, max=0;
            for(int i=0; i<6; i++){
                if(ob[i].initialPercent<u){
                    u=ob[i].initialPercent;
                    min=i;
                }
                if(ob[i].initialPercent>v){
                    v=ob[i].initialPercent;
                    max=i;
                }
            }

            if(max>3 && min<4){
                for(int j=0; j<6; j++){
                    ob[min].a[j]=ob[max].a[j];
                }
            }
            
            z++;
            System.out.println("LOOP " + z +" LOOP " + z +" LOOP " + z +" LOOP " + z);
        }
        
    }
    
}
