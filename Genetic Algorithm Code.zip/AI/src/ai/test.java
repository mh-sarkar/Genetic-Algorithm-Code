package ai;
public class test {
    int a[]={0,0,0,0,0,0};
    double initialPercent=0.0;
    int count=0;
    double finalPercent= 0.0;
    int randCount=0;
}
